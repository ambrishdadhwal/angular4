import { Directive } from '@angular/core';
import { Component, OnInit, Input, } from '@angular/core';

@Directive({
  selector: '[appConfirm]'
})
export class ConfirmDirective {
  @Input() appConfirm =() => {};
  

  constructor() { }

}