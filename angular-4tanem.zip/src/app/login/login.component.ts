import { Component, OnInit } from '@angular/core';

 class User {
  fname:String;
  lname:String;
  pass:String;
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user : User = {fname:'',lname:'',pass:''};
  
  constructor() { }
  onSubmit(user){
    console.log(user.fname);
    console.log(user.lname);
    console.log(user.pass);
  };

  ngOnInit() {
    this.user;
  }

}