import { Component, OnInit } from '@angular/core';
import { ActivityService } from '../obserable/activity.service';
import {Student} from './Student';

@Component({
  selector: 'app-obserable',
  templateUrl: './obserable.component.html',
  styleUrls: ['./obserable.component.css']
})


export class ObserableComponent implements OnInit {

  students: Student;
  constructor(private activityService : ActivityService) { }
  
 
  ngOnInit() {
        this.getStudents();
  }

  getStudents(): void {
    
    this.activityService.getActivities().subscribe(students => this.students = students);
  }

}