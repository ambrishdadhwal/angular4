import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {Student} from './Student';

@Injectable()
export class ActivityService {

  constructor(private http: Http,student:Student) { }
  public getActivities():Observable<Student>{
    console.log(this.http.get('https://reqres.in/api/users/2').map(res=>res.json().data));
    return this.http.get('https://reqres.in/api/users/2').map(res=>res.json().data);
  }


}