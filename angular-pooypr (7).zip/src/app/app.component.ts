import { Component } from '@angular/core';
import {MyservicenameService} from './myservicename.service'

@Component({
  selector: 'my-app',
  template:
      `<h3>{{title}}</h3>
        <nav>
        <a [routerLink]="['/fblogin']">Facebook Login</a> &nbsp;
        <a [routerLink]="['/dashboard']">Dashboard</a> &nbsp;
        <a [routerLink]="['/']">Home</a> &nbsp;
        <a [routerLink]="['/about']">About</a>&nbsp;
        <a [routerLink]="['/forms']">Forms</a> &nbsp;
        <a [routerLink]="['/modelpractice']">Model practice</a> &nbsp;
        <a [routerLink]="['/login']">Model practice</a> &nbsp;
        <a [routerLink]="['/obserable']">Obserable</a> &nbsp;
      </nav>
      <div class="outer-outlet">
        <router-outlet></router-outlet>
      </div>
              `,
      providers:[MyservicenameService]

})
export class AppComponent  {

  constructor(private myService:MyservicenameService){

  }
  title:String='';
  ngOnInit(){
    this.title = this.myService.doSomething();
  }
  name = 'World';
  show : boolean = true; 
}
