import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AboutHomeComponent } from './about/about-home/about-home.component';
import { AboutItemComponent } from './about/about-item/about-item.component';
import { ConfirmDirective } from './confirm.directive';
import { FormsComponent } from './forms/forms.component';
import { ModelpracticeComponent } from './modelpractice/modelpractice.component';
import { LoginComponent } from './login/login.component';
import { MyservicenameService } from './myservicename.service';
import { ObserableComponent } from './obserable/obserable.component';
import { ActivityService } from './obserable/activity.service';
import { FacebookloginComponent } from './facebooklogin/facebooklogin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthguardserviceService } from './facebooklogin/authguardservice.service';
import { Authservice1Service } from './facebooklogin/authservice1.service';

const appRoutes : Routes =
[
  {path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path:'about',
    component:AboutComponent,
    children:[
    {
      path:'',
      component:AboutHomeComponent
    },
    {
      path:'aboutItem/:id',
      component:AboutItemComponent
    }
    ]
  },
  {path: 'forms', component:FormsComponent },
  {path: 'modelpractice', component:ModelpracticeComponent },
  {path: 'login', component:LoginComponent },
  {path: 'obserable', component:ObserableComponent },
  {path: 'fblogin', component:FacebookloginComponent },
  {path: 'dashboard', component:DashboardComponent },
  {path :'**',component:HomeComponent}
];

@NgModule({
  imports:      [ BrowserModule, FormsModule,RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent, HelloComponent, HomeComponent, AboutComponent, AboutHomeComponent, AboutItemComponent, ConfirmDirective, FormsComponent, ModelpracticeComponent, LoginComponent, ObserableComponent, FacebookloginComponent, DashboardComponent ],
  bootstrap:    [ AppComponent ],
  providers: [MyservicenameService, ActivityService, AuthguardserviceService, Authservice1Service]
})
export class AppModule { }
