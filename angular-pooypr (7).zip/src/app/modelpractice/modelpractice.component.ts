import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modelpractice',
  templateUrl: './modelpractice.component.html',
  styleUrls: ['./modelpractice.component.css']
})
export class ModelpracticeComponent implements OnInit {

  sendData(mobile :number,state : string,country:string){
    console.log(mobile);
    console.log(state);
    console.log(country);
  }
  constructor() { }

  ngOnInit() {
  }

}