import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Obserable } from 'rxjs/Obserable';

@Injectable()
export class ActivityService {

  constructor() { }
  

}