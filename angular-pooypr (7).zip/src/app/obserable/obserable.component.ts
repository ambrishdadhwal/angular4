import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-obserable',
  templateUrl: './obserable.component.html',
  styleUrls: ['./obserable.component.css']
})
export class ObserableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}