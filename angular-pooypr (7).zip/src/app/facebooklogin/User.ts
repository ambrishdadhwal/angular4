export class User{
  username:String;
  pass:String;
}