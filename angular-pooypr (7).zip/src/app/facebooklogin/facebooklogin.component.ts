import { Component, OnInit } from '@angular/core';
import { User } from './User';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
}                           from '@angular/router';

import { AuthService } from './authservice';

@Component({
  selector: 'app-facebooklogin',
  templateUrl: './facebooklogin.component.html',
  styleUrls: ['./facebooklogin.component.css']
})
export class FacebookloginComponent implements OnInit {

  user: User =
    {
      username: '',
      pass: ''
    }
  constructor(public authService: AuthService, public router: Router) { }

  submit(user){
      console.log(user.username);
      console.log(user.pass);
       this.authService.login().subscribe(() => {
      if (this.authService.isLoggedIn) {
        // Get the redirect URL from our auth service
        // If no redirect has been set, use the default
        let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/crisis-center/admin';
 
        // Redirect the user
        this.router.navigate([redirect]);
      }
    });

  }
  verifyUser(user):boolean{
    if(user.username =='123' && user.pass=='123'){
      return true;
    }
      return false;
  }
  ngOnInit() {
    this.user;
  }

}