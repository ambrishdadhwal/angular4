import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { CrisisListComponent } from './crisis-list/crisis-list.component';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MyModuleModule } from './my-module/my-module.module';

import { HeroesModule } from './heros/heroes-module/heroes-module.module';
import { AdminModule } from './admin/admin.module';
import { AuthGuard } from './auth/auth.guard';
import { AuthModuleModule } from './auth/auth-module/auth-module.module';


@NgModule({
  imports: [BrowserModule, FormsModule, MyModuleModule, RouterModule, HeroesModule, AdminModule,AuthModuleModule],
  declarations: [AppComponent, HelloComponent, CrisisListComponent, PageNotFoundComponent],
  bootstrap: [AppComponent],
  providers: [AuthGuard]
})
export class AppModule { }
