import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CrisisListComponent } from '../crisis-list/crisis-list.component';
import { HeroListComponent } from '../heros/hero-list/hero-list.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { HeroesRoutingModule } from '../heros/heroes-routing/heroes-routing.module';
import { AdminRoutingModule } from '../admin/admin-routing/admin-routing.module';
import {AuthRoutingModule} from '../auth/auth-routing/auth-routing.module';

const appRoutes: Routes = [
  { path: 'crisis-center', component: CrisisListComponent },
  { path: '',   redirectTo: '/heroes', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes),
    HeroesRoutingModule,
    AdminRoutingModule,
    AuthRoutingModule
  ],
  declarations: []
})
export class MyModuleModule { }