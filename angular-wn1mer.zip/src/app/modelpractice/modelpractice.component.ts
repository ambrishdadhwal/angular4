import { Component, OnInit } from '@angular/core';


 class Person{
  id:String;
  userName:String;
  email:String;
}

@Component({
  selector: 'app-modelpractice',
  templateUrl: './modelpractice.component.html',
  styleUrls: ['./modelpractice.component.css']
})
export class ModelpracticeComponent implements OnInit {

  person: Person = { id: '', userName: '', email: '' };

  sendData(mobile: number, state: string, country: string) {
    //console.log(mobile);
    ////console.log(state);
   // console.log(country);
  }
  sendPersonData(person){
   // alert('adsfa');
    console.log(person.id);
    console.log(person.userName);
    console.log(person.email);
  }
  constructor() { }

  ngOnInit() {
    this.person;
  }

}