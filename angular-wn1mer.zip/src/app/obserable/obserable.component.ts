import { Component, OnInit } from '@angular/core';
import { ActivityService } from '../obserable/activity.service';
import { Student } from './Student';

@Component({
  selector: 'app-obserable',
  templateUrl: './obserable.component.html',
  styleUrls: ['./obserable.component.css']
})


export class ObserableComponent implements OnInit {

  titles: Student[];
  student: Student;
  constructor(private activityService: ActivityService) { }
  httpData;


  ngOnInit() {
    this.getStudents();
    
  }


  getStudents(): void {
    this.httpData = this.activityService.getActivities().
      subscribe(data => {
        this.displaydata(data);
        
      });
  }

  displaydata(data) { this.httpData = data; }

}