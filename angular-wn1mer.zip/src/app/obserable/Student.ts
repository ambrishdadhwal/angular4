export class Student{
  id:String;
  name:String;
  username:String;
  email:String;
  phone:String;
  website:String;
}