import { Injectable } from '@angular/core';

@Injectable()
export class MyservicenameService {

  constructor() { }
  doSomething(){
    return "hello world";
  }

}