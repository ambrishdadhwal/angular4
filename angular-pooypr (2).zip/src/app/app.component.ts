import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:
      `<nav>
        <a [routerLink]="['/']">Home</a> &nbsp;
        <a [routerLink]="['/about']">About</a>
      </nav>
      <div class="outer-outlet">
        <router-outlet></router-outlet>
      </div>
      <button (click) ="show = !show">{{show?'hide' : 'show'}}</button>
    <p ngif="show">wow!! i am showing!!!!</p>
        `

})
export class AppComponent  {
  name = 'World';
  show : boolean = true; 
}
