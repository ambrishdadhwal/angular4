import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AboutHomeComponent } from './about/about-home/about-home.component';
import { AboutItemComponent } from './about/about-item/about-item.component';
import { ConfirmDirective } from './confirm.directive';

const appRoutes : Routes =
[
  {path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path:'about',
    component:AboutComponent,
    children:[
    {
      path:'',
      component:AboutHomeComponent
    },
    {
      path:'aboutItem/:id',
      component:AboutItemComponent
    }
    ]
  },
  {path :'**',component:HomeComponent}
];

@NgModule({
  imports:      [ BrowserModule, FormsModule,RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent, HelloComponent, HomeComponent, AboutComponent, AboutHomeComponent, AboutItemComponent, ConfirmDirective ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
