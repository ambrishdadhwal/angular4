import { NgModule } from '@angular/core';

import { AboutRoutingModule } from './about-routing.module';

@NgModule({
  imports:      [ AboutRoutingModule ],
  declarations: [ AboutRoutingModule.components ]
})
export class AboutModule { }
